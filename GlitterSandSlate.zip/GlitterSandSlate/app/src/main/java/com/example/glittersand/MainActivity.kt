package com.example.glittersand

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint as AndroidPaint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

enum class ToolMode {
    STICK, DUSTER
}

data class GlitterPalette(
    val name: String,
    val colors: List<Color>,
    val highlightColor: Color = Color.White
) {
    val argbColors: IntArray by lazy { colors.map { it.toArgb() }.toIntArray() }
    val argbHighlight: Int by lazy { highlightColor.toArgb() }

    companion object {
        val RainbowBright = GlitterPalette(
            name = "Rainbow",
            colors = listOf(
                Color(0xFFFF1744), Color(0xFFFF9100), Color(0xFFFFEA00),
                Color(0xFF00E676), Color(0xFF00E5FF), Color(0xFFD500F9)
            )
        )
        val OceanSparkle = GlitterPalette(
            name = "Ocean",
            colors = listOf(
                Color(0xFF00E5FF), Color(0xFF00B0FF), Color(0xFF2979FF),
                Color(0xFF1DE9B6), Color(0xFFE0F7FA)
            )
        )
        val GoldDust = GlitterPalette(
            name = "Gold",
            colors = listOf(
                Color(0xFFFFD700), Color(0xFFFFC107), Color(0xFFFFE082),
                Color(0xFFFFA000), Color(0xFFFFF8E1)
            )
        )
        val CosmicRose = GlitterPalette(
            name = "Cosmic Rose",
            colors = listOf(
                Color(0xFFFF4081), Color(0xFFF50057), Color(0xFF7C4DFF),
                Color(0xFFB388FF), Color(0xFFFCE4EC)
            )
        )
        val All = listOf(RainbowBright, OceanSparkle, GoldDust, CosmicRose)
    }
}

class ShakeDetector(
    context: Context,
    private val threshold: Float = 14.0f,
    private val onShake: () -> Unit
) : SensorEventListener {
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private var lastShakeTimestamp: Long = 0

    fun start() {
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    fun stop() {
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return
        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]
        val gForce = sqrt((x * x + y * y + z * z).toDouble()).toFloat() - SensorManager.GRAVITY_EARTH

        if (gForce > threshold) {
            val now = System.currentTimeMillis()
            if (now - lastShakeTimestamp > 1000) {
                lastShakeTimestamp = now
                onShake()
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

class SlateSoundEngine(context: Context) {
    private val soundPool: SoundPool = SoundPool.Builder()
        .setMaxStreams(2)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_GAME)
                .build()
        )
        .build()

    private var scratchSoundId: Int = 0
    private var flowStreamId: Int = 0
    private var isFlowing: Boolean = false

    init {
        val scratchRes = context.resources.getIdentifier("scratch", "raw", context.packageName)
        if (scratchRes != 0) {
            scratchSoundId = soundPool.load(context, scratchRes, 1)
        }
    }

    fun onDrawingStarted() {
        if (scratchSoundId != 0 && !isFlowing) {
            flowStreamId = soundPool.play(scratchSoundId, 0.4f, 0.4f, 1, -1, 1.0f)
            isFlowing = true
        }
    }

    fun onDrawingMoved(velocity: Float) {
        if (isFlowing && flowStreamId != 0) {
            val rate = (0.8f + (velocity / 2000f).coerceIn(0f, 0.7f))
            val volume = (0.2f + (velocity / 1500f).coerceIn(0f, 0.6f))
            soundPool.setRate(flowStreamId, rate)
            soundPool.setVolume(flowStreamId, volume, volume)
        }
    }

    fun onDrawingStopped() {
        if (isFlowing && flowStreamId != 0) {
            soundPool.stop(flowStreamId)
            isFlowing = false
        }
    }

    fun release() {
        soundPool.release()
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var shakeDetector: ShakeDetector
    private var shakeCount by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        shakeDetector = ShakeDetector(this) { shakeCount++ }
        setContent {
            MaterialTheme {
                GlitterSlateScreen(shakeCount = shakeCount, onClearRequested = { shakeCount++ })
            }
        }
    }

    override fun onResume() {
        super.onResume()
        shakeDetector.start()
    }

    override fun onPause() {
        super.onPause()
        shakeDetector.stop()
    }
}

@Composable
fun GlitterSlateScreen(shakeCount: Int, onClearRequested: () -> Unit) {
    val context = LocalContext.current
    val soundEngine = remember { SlateSoundEngine(context) }
    DisposableEffect(Unit) {
        onDispose { soundEngine.release() }
    }

    var selectedPalette by remember { mutableStateOf(GlitterPalette.RainbowBright) }
    var toolMode by remember { mutableStateOf(ToolMode.STICK) }
    var toolPosition by remember { mutableStateOf<Offset?>(null) }

    Box(modifier = Modifier.fillMaxSize()) {
        GlitterSlateCanvas(
            palette = selectedPalette,
            toolMode = toolMode,
            soundEngine = soundEngine,
            onToolPositionChange = { toolPosition = it },
            shakeTrigger = shakeCount
        )

        VirtualToolOverlay(
            toolPosition = toolPosition,
            toolMode = toolMode
        )

        FloatingToolbox(
            selectedPalette = selectedPalette,
            toolMode = toolMode,
            onPaletteSelect = {
                selectedPalette = it
                toolMode = ToolMode.STICK
            },
            onToolModeToggle = {
                toolMode = if (toolMode == ToolMode.STICK) ToolMode.DUSTER else ToolMode.STICK
            },
            onClearAll = onClearRequested,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 32.dp)
        )
    }
}

@Composable
fun GlitterSlateCanvas(
    modifier: Modifier = Modifier,
    palette: GlitterPalette,
    toolMode: ToolMode,
    soundEngine: SlateSoundEngine?,
    onToolPositionChange: (Offset?) -> Unit,
    shakeTrigger: Int
) {
    var canvasSize by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var bitmapBuffer by remember { mutableStateOf<Bitmap?>(null) }
    var offscreenCanvas by remember { mutableStateOf<AndroidCanvas?>(null) }
    var drawCounter by remember { mutableIntStateOf(0) }

    val sandPaint = remember { AndroidPaint().apply { isAntiAlias = true; style = AndroidPaint.Style.FILL } }
    val shadowPaint = remember {
        AndroidPaint().apply {
            isAntiAlias = true
            style = AndroidPaint.Style.FILL
            color = android.graphics.Color.argb(80, 10, 10, 12)
        }
    }
    val eraserPaint = remember {
        AndroidPaint().apply {
            isAntiAlias = true
            style = AndroidPaint.Style.FILL
            xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }
    }

    LaunchedEffect(shakeTrigger) {
        if (shakeTrigger > 0) {
            offscreenCanvas?.drawColor(android.graphics.Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
            drawCounter++
        }
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(palette, toolMode) {
                var lastPoint: Offset? = null
                var lastTime: Long = 0

                detectDragGestures(
                    onDragStart = { startOffset ->
                        lastPoint = startOffset
                        lastTime = System.currentTimeMillis()
                        onToolPositionChange(startOffset)
                        soundEngine?.onDrawingStarted()
                        offscreenCanvas?.let { canvas ->
                            stampSandCluster(canvas, startOffset, palette, toolMode, sandPaint, shadowPaint, eraserPaint)
                            drawCounter++
                        }
                    },
                    onDragEnd = {
                        lastPoint = null
                        onToolPositionChange(null)
                        soundEngine?.onDrawingStopped()
                    },
                    onDragCancel = {
                        lastPoint = null
                        onToolPositionChange(null)
                        soundEngine?.onDrawingStopped()
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        val currentPoint = change.position
                        onToolPositionChange(currentPoint)

                        val currentTime = System.currentTimeMillis()
                        val dt = (currentTime - lastTime).coerceAtLeast(1)
                        val prev = lastPoint ?: currentPoint
                        val distance = hypot(currentPoint.x - prev.x, currentPoint.y - prev.y)
                        val velocity = (distance / dt) * 1000f

                        soundEngine?.onDrawingMoved(velocity)

                        offscreenCanvas?.let { canvas ->
                            val stepSize = if (toolMode == ToolMode.DUSTER) 12f else 5f
                            val steps = (distance / stepSize).toInt().coerceAtLeast(1)
                            for (i in 1..steps) {
                                val t = i.toFloat() / steps
                                val interpolated = Offset(
                                    prev.x + (currentPoint.x - prev.x) * t,
                                    prev.y + (currentPoint.y - prev.y) * t
                                )
                                stampSandCluster(canvas, interpolated, palette, toolMode, sandPaint, shadowPaint, eraserPaint)
                            }
                            drawCounter++
                        }
                        lastPoint = currentPoint
                        lastTime = currentTime
                    }
                )
            }
    ) {
        val width = size.width.toInt()
        val height = size.height.toInt()

        if (width > 0 && height > 0 && (canvasSize?.first != width || canvasSize?.second != height)) {
            canvasSize = Pair(width, height)
            val newBmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val newCanvas = AndroidCanvas(newBmp)
            bitmapBuffer?.let { old ->
                newCanvas.drawBitmap(old, 0f, 0f, null)
                old.recycle()
            }
            bitmapBuffer = newBmp
            offscreenCanvas = newCanvas
        }

        drawSlateSurface(size.width, size.height)

        bitmapBuffer?.let { bmp ->
            if (drawCounter >= 0) {
                drawImage(bmp.asImageBitmap())
            }
        }
    }
}

private fun stampSandCluster(
    canvas: AndroidCanvas,
    center: Offset,
    palette: GlitterPalette,
    toolMode: ToolMode,
    sandPaint: AndroidPaint,
    shadowPaint: AndroidPaint,
    eraserPaint: AndroidPaint
) {
    if (toolMode == ToolMode.DUSTER) {
        canvas.drawCircle(center.x, center.y, 55f, eraserPaint)
        return
    }

    val particleCount = 14
    val scatterRadius = 18f
    val colors = palette.argbColors
    val highlight = palette.argbHighlight

    for (i in 0 until particleCount) {
        val angle = Random.nextFloat() * 6.28318f
        val r = Random.nextFloat() * scatterRadius
        val px = center.x + r * cos(angle)
        val py = center.y + r * sin(angle)
        val particleRadius = Random.nextFloat() * 2.8f + 1.2f

        canvas.drawCircle(px + 1.2f, py + 1.8f, particleRadius, shadowPaint)

        sandPaint.color = colors[Random.nextInt(colors.size)]
        canvas.drawCircle(px, py, particleRadius, sandPaint)

        if (Random.nextFloat() < 0.35f) {
            sandPaint.color = highlight
            canvas.drawCircle(px - 0.4f, py - 0.4f, particleRadius * 0.45f, sandPaint)
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSlateSurface(w: Float, h: Float) {
    drawRect(color = Color(0xFF16181B))
    drawIntoCanvas { canvas ->
        val paint = AndroidPaint().apply {
            color = android.graphics.Color.WHITE
            alpha = 10
            strokeWidth = 1f
        }
        val rand = Random(42)
        for (i in 0..1200) {
            val rx = rand.nextFloat() * w
            val ry = rand.nextFloat() * h
            canvas.nativeCanvas.drawPoint(rx, ry, paint)
        }
    }
}

@Composable
fun VirtualToolOverlay(toolPosition: Offset?, toolMode: ToolMode) {
    if (toolPosition == null) return

    Canvas(modifier = Modifier.fillMaxSize()) {
        val x = toolPosition.x
        val y = toolPosition.y

        if (toolMode == ToolMode.STICK) {
            val stickPath = Path().apply {
                moveTo(x, y)
                lineTo(x + 28f, y - 85f)
                lineTo(x + 48f, y - 75f)
                close()
            }
            drawPath(path = stickPath, color = Color(0xFFC18A45))
            drawPath(path = stickPath, color = Color(0xFF6D4C1B), style = Stroke(width = 2.5f))
            drawCircle(color = Color(0xFF3E2723), radius = 3f, center = Offset(x, y))
        } else {
            drawCircle(color = Color.White.copy(alpha = 0.25f), radius = 55f, center = Offset(x, y))
            drawCircle(color = Color.White.copy(alpha = 0.7f), radius = 55f, center = Offset(x, y), style = Stroke(width = 2f))
        }
    }
}

@Composable
fun FloatingToolbox(
    selectedPalette: GlitterPalette,
    toolMode: ToolMode,
    onPaletteSelect: (GlitterPalette) -> Unit,
    onToolModeToggle: () -> Unit,
    onClearAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.shadow(elevation = 12.dp, shape = RoundedCornerShape(24.dp)),
        color = Color(0xCC23272E),
        shape = RoundedCornerShape(24.dp),
        tonalElevation = 6.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            GlitterPalette.All.forEach { palette ->
                val isSelected = palette == selectedPalette && toolMode == ToolMode.STICK
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Brush.sweepGradient(palette.colors))
                        .then(
                            if (isSelected) Modifier.border(2.5.dp, Color.White, CircleShape)
                            else Modifier
                        )
                        .clickable { onPaletteSelect(palette) }
                )
            }

            VerticalDivider(
                modifier = Modifier.height(28.dp),
                color = Color.White.copy(alpha = 0.2f)
            )

            IconButton(onClick = onToolModeToggle) {
                Icon(
                    imageVector = if (toolMode == ToolMode.STICK) Icons.Default.AutoFixHigh else Icons.Default.Edit,
                    contentDescription = "Toggle Eraser",
                    tint = if (toolMode == ToolMode.DUSTER) Color(0xFFFFD54F) else Color.White
                )
            }

            IconButton(onClick = onClearAll) {
                Icon(
                    imageVector = Icons.Default.DeleteSweep,
                    contentDescription = "Clear Slate",
                    tint = Color.White.copy(alpha = 0.85f)
                )
            }
        }
    }
}
